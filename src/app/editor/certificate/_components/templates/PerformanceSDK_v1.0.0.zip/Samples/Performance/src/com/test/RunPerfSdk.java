package com.test;

import com.samsung.sdk.sperf.CustomParams;
import com.samsung.sdk.sperf.PerformanceManager;
import com.samsung.sdk.sperf.SPerf;

import android.content.Context;

public class RunPerfSdk {
	private boolean isInitialized = false;
	private PerformanceManager pm = null;
	
	public void runPerfSDK(Context context) {
		init(context); //initialize
		requestPerfSdkCustom(); // request Custom Parameters
		requestPerfSdkPreSet(); // request Preset Parameters
	}
	
	public void init(Context context) {
		SPerf.setDebugModeEnabled(true); // set Debug Mode to See the Log
		isInitialized = SPerf.initialize(context); // initialize the PerfSDK

		pm = PerformanceManager.getInstance();		
		if(pm == null) {
			isInitialized = false;
		}
	}
	
	public void requestPerfSdkCustom() {
		if(!isInitialized || pm == null) {
			return;
		}
		
		CustomParams param = new CustomParams(); // Custom Parameters to request. Reusable.
		param.add(CustomParams.TYPE_CPU_MIN, 2, 1000); // Add CPU Frequency Minimum Limit Param
		param.add(CustomParams.TYPE_BUS_MAX, 3, 500); // Add BUS Frequency Maximum Limit Param
		
		pm.start(param); // Request to set added parameter as system resource
	}
	
	public void requestPerfSdkPreSet() {
		if(!isInitialized || pm == null) {
			return;
		}
		pm.start(PerformanceManager.PRESET_TYPE_BUS|PerformanceManager.PRESET_TYPE_CPU, 1000); // Request to set preset parameter as system resource
	}
}
