package com.test;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import android.content.Context;
import android.util.Log;
import dalvik.system.PathClassLoader;

public class Sample {
    private static final String PERF_SDK_PATH = "/system/framework/perfsdk.jar";
    Object perfsdk = null;
    Object sperf = null;
    Method sperfMethods[] = null;
    int SPERF_INIT = -1;
    int SPERF_DEBUG = -1;
    
    Object performanceManager = null;
    Object customParams = null;
    
    public void init(Context context) {
        if(new File(PERF_SDK_PATH).exists()) {
            perfsdk = new PathClassLoader(PERF_SDK_PATH, ClassLoader.getSystemClassLoader());
        } else {
            Log.e("BJS", "PerfSDK Not Exist");
            return;
        }
        
        try {
            sperf = ((ClassLoader)perfsdk).loadClass("com.samsung.sdk.sperf.SPerf");
            performanceManager = ((ClassLoader)perfsdk).loadClass("com.samsung.sdk.sperf.PerformanceManager");
            customParams = ((ClassLoader)perfsdk).loadClass("com.samsung.sdk.sperf.CustomParams");

            sperfMethods = sperf.getClass().getDeclaredMethods();
            for (int i = 0; i < sperfMethods.length; i++) {
                Method m = sperfMethods[i];
                if(m.getName().contains("initialize")) {
                    SPERF_INIT = i;
                } else if (m.getName().contains("setDebugModeEnabled")) {
                    SPERF_DEBUG = i;
                }
            }

            if(SPERF_DEBUG != -1) {
                sperfMethods[SPERF_DEBUG].invoke(false);
            }
            if(SPERF_INIT != -1) {
                sperfMethods[SPERF_INIT].invoke(context);
            }
            Log.e("BJS", "Finish~!~!#!@$@#$%^*%$#*P(%");
            
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            Log.e("BJS", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            Log.e("BJS", "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB");
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            Log.e("BJS", "CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC");
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            Log.e("BJS", "DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD");
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
