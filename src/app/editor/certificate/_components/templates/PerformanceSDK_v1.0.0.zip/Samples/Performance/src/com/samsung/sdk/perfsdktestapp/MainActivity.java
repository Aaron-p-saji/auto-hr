package com.samsung.sdk.perfsdktestapp;


import com.example.pefsdktestapp.R;
import com.samsung.sdk.sperf.CustomParams;
import com.samsung.sdk.sperf.PerformanceManager;
import com.samsung.sdk.sperf.SPerf;
import com.test.Sample;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {

	private static final String TAG = "BJS";
	private TextView textView;
	private int count = 0;
	private int type = 0;

	private static final int MAX_IDX = 6;

	private TextView[] timeouts = new TextView[MAX_IDX];
	private TextView[] levels = new TextView[MAX_IDX];
	private Button[] buttons = new Button[MAX_IDX];
	
	public static int scene_type = 0;
	
	public static PerformanceManager pm = null;
	
	public Context mContext = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		Sample s = new Sample();
		s.init(this.getApplicationContext());

		mContext = this.getApplicationContext();
		
		try{
			SPerf.setDebugModeEnabled(true);
			SPerf.initialize(mContext);
			Log.i("PERFSDK_TEST", SPerf.getVersionName() + "   :   " + SPerf.getVersionCode());
			pm = PerformanceManager.getInstance();
            int a = CustomParams.TYPE_TASK_AFFINITY;
		}catch(UnsatisfiedLinkError e){
			e.printStackTrace();
			Log.i("BJS","ERRRRRRRR");
		} catch (NoSuchMethodError e) {
		    e.printStackTrace();
		}
		createLayout();
	}

	private CustomParams params = null;
	public void addReqBtnListener(final EditText level, final EditText timeout, Button btn) {
		btn.setOnClickListener(new OnClickListener() { 

			@Override
			public void onClick(View v) {
				String levelStr, timeoutStr;
				int levelVal = -1, timeoutVal = -1;

				levelStr = level.getText().toString();
				timeoutStr = timeout.getText().toString();
				try {
					if (levelStr.length() > 0) {
						levelVal = Integer.parseInt(levelStr);
					}
				} catch (Exception e) {
					levelVal = -1;
				}

				try {
					if (timeoutStr.length() > 0) {
						timeoutVal = Integer.parseInt(timeoutStr);
					}
				} catch (Exception e) {
					timeoutVal = -1;
				}
				String tag = v.getTag().toString();
				String split[] = tag.split("_");
				if (split.length == 2) {
					try {
						if(params == null) {
							params = new CustomParams();
							int a = CustomParams.TYPE_TASK_AFFINITY;
						}
						int type = Integer.parseInt(split[1]);
						int ret = params.add(type, levelVal, timeoutVal);
						Log.i("PERFSDK_TEST", "type - " + type + "    level - " + levelVal + "    timeout - " + timeoutVal + "        ret -> " + ret);
					} catch (Exception e) {

					}
				} else {
					try {
						if(params == null) {
							params = new CustomParams();
						}
						EditText et = (EditText) findViewById(R.id.text_param_type);
						int type = Integer.parseInt(et.getText().toString());
						int ret = params.add(type, levelVal, timeoutVal);
						Log.i("PERFSDK_TEST", "type - " + type + "    level - " + levelVal + "    timeout - " + timeoutVal + "        ret -> " + ret);
					} catch (NumberFormatException e){
						Log.i("PERFSDK_TEST", "check type...");
						e.printStackTrace();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		});
	}

	public void createLayout() {
		EditText level, timeout;
		Button btn;
		String split[];
		int type;
		
		Button initBtn = (Button)findViewById(R.id.init_btn);
		initBtn.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View arg0) {
            }
        });
		
		EditText eType;
		eType = (EditText) findViewById(R.id.text_param_type);
		level = (EditText) findViewById(R.id.text_param_level);
		timeout = (EditText) findViewById(R.id.text_param_timeout);
		btn = (Button) findViewById(R.id.text_param_btn);
		split = btn.getTag().toString().split("_");
		if (split.length == 2) {
			type = Integer.parseInt(split[1]);
			level.setHint(4 + " level");
			timeout.setHint(-1 + " timeout(ms)");
		}
		addReqBtnListener(level, timeout, btn);
		
		level = (EditText) findViewById(R.id.cpumin_level);
		timeout = (EditText) findViewById(R.id.cpumin_timeout);
		btn = (Button) findViewById(R.id.cpumin_btn);
		split = btn.getTag().toString().split("_");
		if (split.length == 2) {
			type = Integer.parseInt(split[1]);
			level.setHint(4 + " level");
			timeout.setHint(-1 + " timeout(ms)");
		}
		addReqBtnListener(level, timeout, btn);

		level = (EditText) findViewById(R.id.cpumax_level);
		timeout = (EditText) findViewById(R.id.cpumax_timeout);
		btn = (Button) findViewById(R.id.cpumax_btn);
		split = btn.getTag().toString().split("_");
		if (split.length == 2) {
			type = Integer.parseInt(split[1]);
			level.setHint(4 + " level");
			timeout.setHint(-1 + " timeout(ms)");
		}
		addReqBtnListener(level, timeout, btn);

		level = (EditText) findViewById(R.id.gpumin_level);
		timeout = (EditText) findViewById(R.id.gpumin_timeout);
		btn = (Button) findViewById(R.id.gpumin_btn);
		split = btn.getTag().toString().split("_");
		if (split.length == 2) {
			type = Integer.parseInt(split[1]);
			level.setHint(4 + " level");
			timeout.setHint(-1 + " timeout(ms)");
		}
		addReqBtnListener(level, timeout, btn);

		level = (EditText) findViewById(R.id.gpumax_level);
		timeout = (EditText) findViewById(R.id.gpumax_timeout);
		btn = (Button) findViewById(R.id.gpumax_btn);
		split = btn.getTag().toString().split("_");
		if (split.length == 2) {
			type = Integer.parseInt(split[1]);
			level.setHint(4 + " level");
			timeout.setHint(-1 + " timeout(ms)");
		}
		addReqBtnListener(level, timeout, btn);

		level = (EditText) findViewById(R.id.busmin_level);
		timeout = (EditText) findViewById(R.id.busmin_timeout);
		btn = (Button) findViewById(R.id.busmin_btn);
		split = btn.getTag().toString().split("_");
		if (split.length == 2) {
			type = Integer.parseInt(split[1]);
			level.setHint(4 + " level");
			timeout.setHint(-1 + " timeout(ms)");
		}
		addReqBtnListener(level, timeout, btn);

		level = (EditText) findViewById(R.id.busmax_level);
		timeout = (EditText) findViewById(R.id.busmax_timeout);
		btn = (Button) findViewById(R.id.busmax_btn);
		split = btn.getTag().toString().split("_");
		if (split.length == 2) {
			type = Integer.parseInt(split[1]);
			level.setHint(4 + " level");
			timeout.setHint(-1 + " timeout(ms)");
		}
		addReqBtnListener(level, timeout, btn);

		level = (EditText) findViewById(R.id.coremin_level);
		timeout = (EditText) findViewById(R.id.coremin_timeout);
		btn = (Button) findViewById(R.id.coremin_btn);
		split = btn.getTag().toString().split("_");
		if (split.length == 2) {
			type = Integer.parseInt(split[1]);
			level.setHint(1 + " level");
			timeout.setHint(-1 + " timeout(ms)");
		}
		addReqBtnListener(level, timeout, btn);

		level = (EditText) findViewById(R.id.coremax_level);
		timeout = (EditText) findViewById(R.id.coremax_timeout);
		btn = (Button) findViewById(R.id.coremax_btn);
		split = btn.getTag().toString().split("_");
		if (split.length == 2) {
			type = Integer.parseInt(split[1]);
			level.setHint(1 + " level");
			timeout.setHint(-1 + " timeout(ms)");
		}
		addReqBtnListener(level, timeout, btn);

		level = (EditText) findViewById(R.id.cpuawake_level);
		timeout = (EditText) findViewById(R.id.cpuawake_timeout);
		btn = (Button) findViewById(R.id.cpuawake_btn);
		split = btn.getTag().toString().split("_");
		if (split.length == 2) {
			type = Integer.parseInt(split[1]);
			level.setHint(0 + " level");
			timeout.setHint(-1 + " timeout(ms)");
		}
		addReqBtnListener(level, timeout, btn);

		level = (EditText) findViewById(R.id.affinity_level);
		timeout = (EditText) findViewById(R.id.affinity_timeout);
		btn = (Button) findViewById(R.id.affinity_btn);
		split = btn.getTag().toString().split("_");
		if (split.length == 2) {
			type = Integer.parseInt(split[1]);
			level.setHint(2 + " level");
			timeout.setHint(-1 + " timeout(ms)");
		}
		addReqBtnListener(level, timeout, btn);

		level = (EditText) findViewById(R.id.priority_level);
		timeout = (EditText) findViewById(R.id.priority_pid);
		btn = (Button) findViewById(R.id.priority_btn);
		split = btn.getTag().toString().split("_");
		if (split.length == 2) {
			type = Integer.parseInt(split[1]);
			level.setHint(4 + " level");
			timeout.setHint(-1 + " timeout(ms)");
		}
		addReqBtnListener(level, timeout, btn);

		btn = (Button) findViewById(R.id.doboostbtn);
		btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
			    if(MainActivity.pm == null) {
			        Log.i("BJS", "pm is null");
			    }
			    if(params == null) {
                    Log.i("BJS", "param is null");
			    }
				int ret = MainActivity.pm.start(params);
				Log.i("PERFSDK_TEST", "Request Boost    ret -> " + ret);
				params = null;
			}
		});

		btn = (Button) findViewById(R.id.releasebtn);
		btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				int ret = MainActivity.pm.stop();
				Log.i("PERFSDK_TEST", "Stop Boost    ret -> " + ret);
			}
		});

		
		OnCheckedChangeListener ocl = new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				String text = buttonView.getText().toString();
				int type = 0;
				if(text != null) {
					if(text.equals("SCENE_CPU")) {
						type = PerformanceManager.PRESET_TYPE_CPU;
					} else if(text.equals("SCENE_GPU")) {
						type = PerformanceManager.PRESET_TYPE_GPU;
					} else if(text.equals("SCENE_BUS")) {
						type = PerformanceManager.PRESET_TYPE_BUS;
					} 
				}
				if(isChecked) {
					scene_type = scene_type | type;
				} else {
					scene_type = scene_type & (~type);
				}
				Log.i("PERFSDK_TEST", "PRESET TYPE - REQ TYPE : " + type + "   Final TYPE = " + scene_type);
			}
		};
		CheckBox cb = null;
		cb = (CheckBox)findViewById(R.id.cpuscenecheck);
		cb.setOnCheckedChangeListener(ocl);
		cb = (CheckBox)findViewById(R.id.gpuscenecheck);
		cb.setOnCheckedChangeListener(ocl);
		cb = (CheckBox)findViewById(R.id.busscenecheck);
		cb.setOnCheckedChangeListener(ocl);
		
		
		btn = (Button)findViewById(R.id.doscenarioboost);
		btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				TextView tv = (TextView)findViewById(R.id.scenario_timeout);
				String text= tv.getText().toString();
				
				tv = (TextView)findViewById(R.id.scenario_type);
				String typeStr= tv.getText().toString();
				int timeout = 0;
				try{
					int type = Integer.parseInt(typeStr);
					timeout = Integer.parseInt(text);
					
					int ret = MainActivity.pm.start(scene_type|type, timeout);
					Log.i("PERFSDK_TEST", "Request Boost type : " + (scene_type|type) + "  ret -> " + ret);
				}catch (NumberFormatException e) {
					// TODO: handle exception
				    
				}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		return super.onOptionsItemSelected(item);
	}
}

class TestThread extends Thread {
	@Override
	public void run() {
		int i = 0;
		while(true) {
			try {
				sleep(1000);
				Log.i("PERFSDK", "MyPid : " + Process.myPid() + "   MyTid : " + Process.myTid());
				if(i++ > 5) { 
					break;
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

class RunThread extends Thread {
	
	@Override
	public void run() {
//		PerfSDK.setDebug(true);
//		PerfSDK.createPerfSDK();
	}
}